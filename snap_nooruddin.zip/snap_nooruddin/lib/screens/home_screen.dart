import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import '../main.dart';
import '../models/media_item.dart';
import '../services/download_manager.dart';
import 'downloads_screen.dart';
import 'library_screen.dart';
import 'search_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _i = 0;

  @override
  void initState() {
    super.initState();
    Permission.notification.request();
  }

  @override
  Widget build(BuildContext context) {
    final active = context.watch<DownloadManager>().tasks.values
        .where((t) => t.state == TaskState.running).length;
    final pages = [
      const SearchScreen(type: MediaType.music),
      const SearchScreen(type: MediaType.video),
      const DownloadsScreen(),
      const LibraryScreen(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('سناب نورالدين', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: Icon(context.watch<ThemeNotifier>().dark ? Icons.light_mode : Icons.dark_mode),
            onPressed: () => context.read<ThemeNotifier>().toggle(),
          ),
        ],
      ),
      body: IndexedStack(index: _i, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.music_note), label: 'موسيقى'),
          const NavigationDestination(icon: Icon(Icons.movie), label: 'فيديو'),
          NavigationDestination(
            icon: Badge(isLabelVisible: active > 0, label: Text('$active'), child: const Icon(Icons.download)),
            label: 'التحميلات',
          ),
          const NavigationDestination(icon: Icon(Icons.library_music), label: 'مكتبتي'),
        ],
      ),
    );
  }
}
