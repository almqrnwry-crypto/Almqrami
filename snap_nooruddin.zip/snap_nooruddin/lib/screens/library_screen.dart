import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/media_item.dart';
import '../services/download_manager.dart';
import 'player_screen.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  String _size(int b) => b > 1048576 ? '${(b / 1048576).toStringAsFixed(1)} MB' : '${(b / 1024).toStringAsFixed(0)} KB';

  @override
  Widget build(BuildContext context) {
    final dm = context.watch<DownloadManager>();
    if (dm.library.isEmpty) return const Center(child: Text('مكتبتك فارغة'));
    return ListView.builder(
      itemCount: dm.library.length,
      itemBuilder: (_, i) {
        final it = dm.library[i];
        return Dismissible(
          key: ValueKey(it.id),
          background: Container(color: Colors.red, child: const Icon(Icons.delete)),
          onDismissed: (_) => dm.deleteItem(it),
          child: ListTile(
            leading: Icon(it.type == MediaType.music ? Icons.music_note : Icons.movie),
            title: Text(it.title, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(_size(it.size)),
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => PlayerScreen(title: it.title, source: it.path, type: it.type, local: true))),
          ),
        );
      },
    );
  }
}
