import 'dart:io';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:video_player/video_player.dart';
import '../models/media_item.dart';

class PlayerScreen extends StatefulWidget {
  final String title;
  final String source;
  final MediaType type;
  final bool local;
  const PlayerScreen({super.key, required this.title, required this.source, required this.type, this.local = false});
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  AudioPlayer? _audio;
  VideoPlayerController? _vc;
  ChewieController? _cc;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      if (widget.type == MediaType.music) {
        _audio = AudioPlayer();
        widget.local
            ? await _audio!.setFilePath(widget.source)
            : await _audio!.setUrl(widget.source);
        _audio!.play();
      } else {
        _vc = widget.local
            ? VideoPlayerController.file(File(widget.source))
            : VideoPlayerController.networkUrl(Uri.parse(widget.source));
        await _vc!.initialize();
        _cc = ChewieController(videoPlayerController: _vc!, autoPlay: true);
      }
    } catch (_) {
      _error = 'تعذّر تشغيل الملف';
    }
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _audio?.dispose();
    _cc?.dispose();
    _vc?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (_error != null) {
      body = Center(child: Text(_error!));
    } else if (widget.type == MediaType.video) {
      body = _cc == null ? const Center(child: CircularProgressIndicator()) : Chewie(controller: _cc!);
    } else if (_audio == null) {
      body = const Center(child: CircularProgressIndicator());
    } else {
      body = Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.album, size: 140),
          const SizedBox(height: 16),
          Text(widget.title, textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
          StreamBuilder<Duration?>(
            stream: _audio!.durationStream,
            builder: (_, d) => StreamBuilder<Duration>(
              stream: _audio!.positionStream,
              builder: (_, p) {
                final total = d.data?.inMilliseconds ?? 1;
                final pos = (p.data?.inMilliseconds ?? 0).clamp(0, total);
                return Slider(
                  value: pos.toDouble(),
                  max: total.toDouble(),
                  onChanged: (v) => _audio!.seek(Duration(milliseconds: v.toInt())),
                );
              },
            ),
          ),
          StreamBuilder<PlayerState>(
            stream: _audio!.playerStateStream,
            builder: (_, s) {
              final playing = s.data?.playing ?? false;
              return IconButton(
                iconSize: 64,
                icon: Icon(playing ? Icons.pause_circle : Icons.play_circle),
                onPressed: () => playing ? _audio!.pause() : _audio!.play(),
              );
            },
          ),
        ]),
      );
    }
    return Scaffold(appBar: AppBar(title: Text(widget.title, maxLines: 1)), body: body);
  }
}
