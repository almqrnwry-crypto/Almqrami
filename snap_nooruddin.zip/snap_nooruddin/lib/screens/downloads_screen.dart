import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/download_manager.dart';

class DownloadsScreen extends StatelessWidget {
  const DownloadsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dm = context.watch<DownloadManager>();
    final tasks = dm.tasks.values.toList().reversed.toList();
    if (tasks.isEmpty) return const Center(child: Text('لا توجد تحميلات حالياً'));
    return ListView.builder(
      itemCount: tasks.length,
      itemBuilder: (_, i) {
        final t = tasks[i];
        final label = switch (t.state) {
          TaskState.running => 'جارٍ التحميل ${(t.progress * 100).toStringAsFixed(0)}%',
          TaskState.paused => 'متوقف مؤقتاً',
          TaskState.done => 'اكتمل',
          TaskState.failed => 'فشل التحميل',
        };
        return ListTile(
          title: Text(t.item.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label),
            if (t.state != TaskState.done)
              LinearProgressIndicator(value: t.progress == 0 ? null : t.progress),
          ]),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            if (t.state == TaskState.running)
              IconButton(icon: const Icon(Icons.pause), onPressed: () => dm.pause(t.item.id)),
            if (t.state == TaskState.paused || t.state == TaskState.failed)
              IconButton(icon: const Icon(Icons.play_arrow), onPressed: () => dm.resume(t.item.id)),
            IconButton(icon: const Icon(Icons.close), onPressed: () => dm.cancel(t.item.id)),
          ]),
        );
      },
    );
  }
}
