import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/media_item.dart';
import '../services/download_manager.dart';
import '../services/search_service.dart';
import 'player_screen.dart';

class SearchScreen extends StatefulWidget {
  final MediaType type;
  const SearchScreen({super.key, required this.type});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> with AutomaticKeepAliveClientMixin {
  final _c = TextEditingController();
  final _svc = SearchService();
  List<MediaItem> _items = [];
  bool _loading = false;
  String? _msg;

  @override
  bool get wantKeepAlive => true;

  Future<void> _search() async {
    final q = _c.text.trim();
    if (q.isEmpty) {
      // رابط مباشر
      return;
    }
    if (q.startsWith('http')) {
      _direct(q);
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      _loading = true;
      _msg = null;
    });
    final r = await _svc.search(q, widget.type);
    if (!mounted) return;
    setState(() {
      _items = r;
      _loading = false;
      _msg = r.isEmpty ? 'لا توجد نتائج' : null;
    });
  }

  Future<void> _direct(String url) async {
    final u = Uri.tryParse(url);
    final name = (u?.pathSegments.isNotEmpty ?? false) ? u!.pathSegments.last : 'ملف';
    final lower = url.toLowerCase();
    final isAudio = lower.contains('.mp3') || lower.contains('.m4a');
    final isVideo = lower.contains('.mp4') || lower.contains('.webm');
    if (!isAudio && !isVideo) {
      setState(() => _msg = 'الرابط يجب أن يكون مباشراً لملف mp3 أو mp4');
      return;
    }
    try {
      await Dio().head(url);
    } catch (_) {
      setState(() => _msg = 'تعذّر الوصول للرابط');
      return;
    }
    if (!mounted) return;
    context.read<DownloadManager>().start(MediaItem(
          id: 'dl_${url.hashCode}',
          title: name,
          artist: u?.host ?? '',
          thumbnail: '',
          url: url,
          type: isAudio ? MediaType.music : MediaType.video,
          source: 'رابط مباشر',
        ));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('بدأ التحميل')));
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final isMusic = widget.type == MediaType.music;
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: SearchBar(
          controller: _c,
          hintText: isMusic ? 'ابحث عن موسيقى أو الصق رابط mp3' : 'ابحث عن فيديو أو الصق رابط mp4',
          leading: const Icon(Icons.search),
          trailing: [IconButton(icon: const Icon(Icons.clear), onPressed: () => _c.clear())],
          onSubmitted: (_) => _search(),
        ),
      ),
      if (_loading) const LinearProgressIndicator(),
      if (_msg != null) Padding(padding: const EdgeInsets.all(24), child: Text(_msg!)),
      Expanded(
        child: ListView.builder(
          itemCount: _items.length,
          itemBuilder: (_, i) => _tile(_items[i]),
        ),
      ),
    ]);
  }

  Widget _tile(MediaItem m) {
    final dm = context.watch<DownloadManager>();
    final t = dm.tasks[m.id];
    return ListTile(
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: SizedBox(
          width: 64,
          height: 64,
          child: m.thumbnail.isEmpty
              ? const Icon(Icons.image_not_supported)
              : CachedNetworkImage(
                  imageUrl: m.thumbnail,
                  fit: BoxFit.cover,
                  errorWidget: (_, __, ___) => const Icon(Icons.broken_image)),
        ),
      ),
      title: Text(m.title, maxLines: 2, overflow: TextOverflow.ellipsis),
      subtitle: Text('${m.artist} • ${m.source}', maxLines: 1, overflow: TextOverflow.ellipsis),
      onTap: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => PlayerScreen(title: m.title, source: m.url, type: m.type))),
      trailing: t == null || t.state == TaskState.failed
          ? IconButton(icon: const Icon(Icons.download), onPressed: () => dm.start(m))
          : t.state == TaskState.done
              ? const Icon(Icons.check_circle, color: Colors.green)
              : SizedBox(
                  width: 32,
                  height: 32,
                  child: CircularProgressIndicator(value: t.progress == 0 ? null : t.progress)),
    );
  }
}
