enum MediaType { music, video }

class MediaItem {
  final String id;
  final String title;
  final String artist;
  final String thumbnail;
  final String url;
  final MediaType type;
  final String source;

  const MediaItem({
    required this.id,
    required this.title,
    required this.artist,
    required this.thumbnail,
    required this.url,
    required this.type,
    required this.source,
  });
}

class DownloadedItem {
  final int? id;
  final String title;
  final String path;
  final MediaType type;
  final int size;
  final String thumbnail;

  const DownloadedItem({
    this.id,
    required this.title,
    required this.path,
    required this.type,
    required this.size,
    required this.thumbnail,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'path': path,
        'type': type.name,
        'size': size,
        'thumbnail': thumbnail,
      };

  factory DownloadedItem.fromMap(Map<String, Object?> m) => DownloadedItem(
        id: m['id'] as int?,
        title: m['title'] as String,
        path: m['path'] as String,
        type: MediaType.values.byName(m['type'] as String),
        size: m['size'] as int,
        thumbnail: (m['thumbnail'] as String?) ?? '',
      );
}
