import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/home_screen.dart';
import 'services/download_manager.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => DownloadManager()),
      ChangeNotifierProvider(create: (_) => ThemeNotifier(prefs)),
    ],
    child: const SnapNooruddinApp(),
  ));
}

class ThemeNotifier extends ChangeNotifier {
  final SharedPreferences prefs;
  ThemeNotifier(this.prefs);
  bool get dark => prefs.getBool('dark') ?? true;
  void toggle() {
    prefs.setBool('dark', !dark);
    notifyListeners();
  }
}

class SnapNooruddinApp extends StatelessWidget {
  const SnapNooruddinApp({super.key});

  @override
  Widget build(BuildContext context) {
    final t = context.watch<ThemeNotifier>();
    const seed = Color(0xFFFFC107);
    return MaterialApp(
      title: 'سناب نورالدين',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      themeMode: t.dark ? ThemeMode.dark : ThemeMode.light,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: seed),
      darkTheme: ThemeData(
          useMaterial3: true, colorSchemeSeed: seed, brightness: Brightness.dark),
      home: const HomeScreen(),
    );
  }
}
