import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/media_item.dart';

class DbService {
  static Database? _db;

  static Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await openDatabase(
      join(await getDatabasesPath(), 'snap_nooruddin.db'),
      version: 1,
      onCreate: (d, _) => d.execute(
          'CREATE TABLE downloads(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, path TEXT, type TEXT, size INTEGER, thumbnail TEXT)'),
    );
    return _db!;
  }

  static Future<void> insert(DownloadedItem i) async =>
      (await db).insert('downloads', i.toMap()..remove('id'));

  static Future<List<DownloadedItem>> all() async =>
      (await (await db).query('downloads', orderBy: 'id DESC'))
          .map(DownloadedItem.fromMap)
          .toList();

  static Future<void> delete(int id) async =>
      (await db).delete('downloads', where: 'id = ?', whereArgs: [id]);
}
