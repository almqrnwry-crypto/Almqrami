import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../models/media_item.dart';
import 'db_service.dart';

enum TaskState { running, paused, done, failed }

class DownloadTask {
  final MediaItem item;
  double progress = 0;
  TaskState state = TaskState.running;
  CancelToken token = CancelToken();
  DownloadTask(this.item);
}

class DownloadManager extends ChangeNotifier {
  final Dio _dio = Dio();
  final Map<String, DownloadTask> tasks = {};
  List<DownloadedItem> library = [];

  DownloadManager() {
    loadLibrary();
  }

  Future<void> loadLibrary() async {
    library = await DbService.all();
    notifyListeners();
  }

  Future<Directory> _dir(MediaType t) async {
    final base = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
    final d = Directory(p.join(base.path, t == MediaType.music ? 'Music' : 'Videos'));
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  String _safe(String s) => s.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_').trim();

  Future<void> start(MediaItem item) async {
    final existing = tasks[item.id];
    if (existing != null && existing.state == TaskState.running) return;
    final task = DownloadTask(item);
    tasks[item.id] = task;
    notifyListeners();
    await _run(task);
  }

  Future<void> _run(DownloadTask task) async {
    final item = task.item;
    try {
      final dir = await _dir(item.type);
      final ext = item.type == MediaType.music ? 'mp3' : 'mp4';
      final path = p.join(dir.path, '${_safe(item.title)}_${item.id.hashCode.abs()}.$ext');
      final part = File('$path.part');
      int start = await part.exists() ? await part.length() : 0;
      task.token = CancelToken();
      task.state = TaskState.running;
      notifyListeners();

      final res = await _dio.get<ResponseBody>(
        item.url,
        cancelToken: task.token,
        options: Options(
          responseType: ResponseType.stream,
          headers: {if (start > 0) 'range': 'bytes=$start-'},
        ),
      );
      final resumed = res.statusCode == 206;
      if (!resumed) start = 0;
      final total = (int.tryParse(res.headers.value('content-length') ?? '') ?? 0) + start;
      final sink = part.openSync(mode: resumed ? FileMode.append : FileMode.write);
      int received = start;
      try {
        await for (final chunk in res.data!.stream) {
          sink.writeFromSync(chunk);
          received += chunk.length;
          if (total > 0) {
            task.progress = received / total;
            notifyListeners();
          }
        }
      } finally {
        sink.closeSync();
      }
      await part.rename(path);
      task.progress = 1;
      task.state = TaskState.done;
      await DbService.insert(DownloadedItem(
        title: item.title,
        path: path,
        type: item.type,
        size: await File(path).length(),
        thumbnail: item.thumbnail,
      ));
      await loadLibrary();
    } on DioException catch (e) {
      task.state = CancelToken.isCancel(e) ? TaskState.paused : TaskState.failed;
    } catch (_) {
      task.state = TaskState.failed;
    }
    notifyListeners();
  }

  void pause(String id) => tasks[id]?.token.cancel('pause');

  Future<void> resume(String id) async {
    final t = tasks[id];
    if (t != null) await _run(t);
  }

  void cancel(String id) {
    tasks[id]?.token.cancel('cancel');
    tasks.remove(id);
    notifyListeners();
  }

  Future<void> deleteItem(DownloadedItem i) async {
    try {
      await File(i.path).delete();
    } catch (_) {}
    await DbService.delete(i.id!);
    await loadLibrary();
  }
}
