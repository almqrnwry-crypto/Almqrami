/// ضع مفاتيحك هنا (مجانية من مواقع المزوّدين).
/// Jamendo:  https://devportal.jamendo.com
/// Pexels:   https://www.pexels.com/api/
/// Pixabay:  https://pixabay.com/api/docs/
class Config {
  static const jamendoClientId = 'PUT_JAMENDO_CLIENT_ID';
  static const pexelsKey = 'PUT_PEXELS_API_KEY';
  static const pixabayKey = 'PUT_PIXABAY_API_KEY';
}
