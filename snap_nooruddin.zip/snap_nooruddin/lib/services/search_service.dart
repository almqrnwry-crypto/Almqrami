import 'package:dio/dio.dart';
import '../models/media_item.dart';
import 'config.dart';

class SearchService {
  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 20),
  ));

  Future<List<MediaItem>> _safe(Future<List<MediaItem>> f) async {
    try {
      return await f;
    } catch (_) {
      return <MediaItem>[];
    }
  }

  Future<List<MediaItem>> search(String q, MediaType type) async {
    if (q.trim().isEmpty) return [];
    final futures = type == MediaType.music
        ? [_safe(_jamendo(q)), _safe(_archive(q, 'audio', MediaType.music))]
        : [
            _safe(_pexels(q)),
            _safe(_pixabay(q)),
            _safe(_archive(q, 'movies', MediaType.video))
          ];
    final r = await Future.wait(futures);
    return r.expand((e) => e).toList();
  }

  Future<List<MediaItem>> _jamendo(String q) async {
    final res = await _dio.get('https://api.jamendo.com/v3.0/tracks/', queryParameters: {
      'client_id': Config.jamendoClientId,
      'format': 'json',
      'limit': 30,
      'search': q,
      'audiodownload_allowed': true,
    });
    final list = (res.data['results'] as List?) ?? [];
    return list
        .where((e) => (e['audiodownload'] ?? '').toString().isNotEmpty)
        .map((e) => MediaItem(
              id: 'jm_${e['id']}',
              title: e['name'] ?? '',
              artist: e['artist_name'] ?? '',
              thumbnail: e['image'] ?? '',
              url: e['audiodownload'],
              type: MediaType.music,
              source: 'Jamendo',
            ))
        .toList();
  }

  Future<List<MediaItem>> _pexels(String q) async {
    final res = await _dio.get('https://api.pexels.com/videos/search',
        queryParameters: {'query': q, 'per_page': 25},
        options: Options(headers: {'Authorization': Config.pexelsKey}));
    final list = (res.data['videos'] as List?) ?? [];
    final out = <MediaItem>[];
    for (final v in list) {
      final files = (v['video_files'] as List).where((f) => f['file_type'] == 'video/mp4').toList();
      if (files.isEmpty) continue;
      files.sort((a, b) => ((b['width'] ?? 0) as int).compareTo((a['width'] ?? 0) as int));
      final pick = files.firstWhere((f) => (f['width'] ?? 0) <= 1280, orElse: () => files.last);
      out.add(MediaItem(
        id: 'px_${v['id']}',
        title: (v['url'] as String).split('/').where((s) => s.isNotEmpty).last,
        artist: v['user']?['name'] ?? 'Pexels',
        thumbnail: v['image'] ?? '',
        url: pick['link'],
        type: MediaType.video,
        source: 'Pexels',
      ));
    }
    return out;
  }

  Future<List<MediaItem>> _pixabay(String q) async {
    final res = await _dio.get('https://pixabay.com/api/videos/',
        queryParameters: {'key': Config.pixabayKey, 'q': q, 'per_page': 25});
    final list = (res.data['hits'] as List?) ?? [];
    return list.map((v) {
      final vids = v['videos'] as Map;
      final pick = (vids['medium'] ?? vids['small'] ?? vids['large']) as Map;
      return MediaItem(
        id: 'pb_${v['id']}',
        title: (v['tags'] ?? 'video').toString(),
        artist: (v['user'] ?? 'Pixabay').toString(),
        thumbnail: (pick['thumbnail'] ?? '').toString(),
        url: pick['url'],
        type: MediaType.video,
        source: 'Pixabay',
      );
    }).toList();
  }

  Future<List<MediaItem>> _archive(String q, String media, MediaType type) async {
    final res = await _dio.get('https://archive.org/advancedsearch.php', queryParameters: {
      'q': '$q AND mediatype:$media AND licenseurl:*',
      'fl[]': ['identifier', 'title', 'creator'],
      'rows': 15,
      'output': 'json',
    });
    final docs = (res.data['response']?['docs'] as List?) ?? [];
    final out = <MediaItem>[];
    for (final d in docs.take(8)) {
      final id = d['identifier'];
      try {
        final meta = await _dio.get('https://archive.org/metadata/$id');
        final files = (meta.data['files'] as List?) ?? [];
        final ext = type == MediaType.music ? '.mp3' : '.mp4';
        final f = files.firstWhere(
            (f) => (f['name'] as String).toLowerCase().endsWith(ext),
            orElse: () => null);
        if (f == null) continue;
        final creator = d['creator'];
        out.add(MediaItem(
          id: 'ia_${id}_${(f['name'] as String).hashCode.abs()}',
          title: (d['title'] ?? id).toString(),
          artist: (creator is List ? creator.join(', ') : creator ?? 'Internet Archive').toString(),
          thumbnail: 'https://archive.org/services/img/$id',
          url: 'https://archive.org/download/$id/${Uri.encodeComponent(f['name'])}',
          type: type,
          source: 'Internet Archive',
        ));
      } catch (_) {}
    }
    return out;
  }
}
