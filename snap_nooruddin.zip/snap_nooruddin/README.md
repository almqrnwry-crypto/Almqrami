# سناب نورالدين

## التشغيل (مرة واحدة)
1. ثبّت Flutter ثم افتح المجلد في Android Studio.
2. من الطرفية داخل المجلد: `flutter create --org com.nooruddin --project-name snap_nooruddin .`
   (يولّد مجلد android دون المساس بـ lib و pubspec)
3. انسخ `android_manifest_notes/AndroidManifest.xml` فوق `android/app/src/main/AndroidManifest.xml`
4. في `android/app/build.gradle` اجعل `minSdkVersion 21` على الأقل.
5. ضع مفاتيحك في `lib/services/config.dart`
6. `flutter pub get` ثم `flutter run`

## النشر على Google Play
1. أيقونة التطبيق: `flutter_launcher_icons` أو من Android Studio (Image Asset).
2. مفتاح التوقيع: `keytool -genkey -v -keystore ~/upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload`
   ثم اضبط key.properties وsigningConfigs حسب https://docs.flutter.dev/deployment/android
3. `flutter build appbundle --release` وارفع الملف في Play Console.
4. جهّز سياسة الخصوصية، وأضف في وصف التطبيق مصادر المحتوى المرخّص، واحترم شروط Jamendo/Pexels/Pixabay (ذكر المصدر).
